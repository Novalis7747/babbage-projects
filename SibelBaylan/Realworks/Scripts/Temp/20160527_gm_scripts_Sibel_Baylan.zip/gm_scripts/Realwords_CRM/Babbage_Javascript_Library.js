// deze doen het wél extern 

 // aanroep SetAttributeForClassname("role","checkbox_icon","checkbox");
function SetAttributeForClassname(Attribute,Class_Name,Role_Name)

{
                var x = document.getElementsByClassName(Class_Name);
                for (var i = 0; i < x.length; i++)
                {
                               x[i].setAttribute(Attribute, Role_Name);
                }       
}

function RemoveAttributeFromClassname(Attribute,Class_Name)
// Handig als een combobox role="button" als attribuut heeft; dan moet dat verwijderd
{
                var x = document.getElementsByClassName(Class_Name);
                for (var i = 0; i < x.length; i++)
                {
                               x[i].removeAttribute(Attribute);
                }       
}

// Handig als een combobox role="button" als attribuut heeft; dan moet dat verwijderd
// en daarna vervangen worden door role="checkbox"
// Aanroep:  ChangeAttributeForClassname("role","role","checkbox","checkbox_icon");
function ChangeAttributeForClassname(OldAttribute, NewAttribute, NewRole_Name, Class_Name)
{
                var x = document.getElementsByClassName(Class_Name);
                for (var i = 0; i < x.length; i++)
                {
                               x[i].removeAttribute(OldAttribute);
							   x[i].setAttribute(Attribute, Role_Name);
							   
                }       
}
 
function SetRoleForClassname(Class_Name, Role_Name)
{
	SetAttributeForClassname("role",Class_Name,Role_Name)
}


 

function SetAttributeForID(Attribute,xxid,rolename)
	{
  var x=document.getElementById(xxid);
  x.setAttribute(Attribute, rolename);	
  }

 

function SetRoleForID(xxid,rolename)
	{
  var x=document.getElementById(xxid);
  x.setAttribute("role", rolename);	
  }


 

// deze doen het niet extern
function addGlobalStyle(css) 
{
var head, style;
head = document.getElementsByTagName('head')[0];
if (!head) { return; }
style = document.createElement('style');
style.type = 'text/css';
style.innerHTML = css;
head.appendChild(style);
}



// **********************   Icoontjes die niet toegankelijk zijn vervangen door checkbox   ******************
function SetRoleForInvisibleIcon(Class_Name)  
//SetRoleForClassname("menuitem icon fa fa-2x fa-bell-o", "button");
{
	var x = document.getElementsByClassName(Class_Name);
	for (var i = 0; i < x.length; i++)
	{
	    x[i].setAttribute("role", "checkbox");
	    x[i].setAttribute("tabindex", "0");
	    var str = x[i].src;            // image name
	    var res = str.split("/");
	    var res = res[res.length-1];
	    var res = res.split(".");
	    var res = res[0];
	    x[i].setAttribute("aria-label", res);
	}
}


