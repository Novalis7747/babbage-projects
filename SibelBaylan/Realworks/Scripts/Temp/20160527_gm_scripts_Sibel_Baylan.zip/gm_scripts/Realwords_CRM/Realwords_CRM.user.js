// ==UserScript==
// @name        Realworks CRM - Algemeen
// @namespace   http://www.babbage.com/
// @include     *://crm.realworks.nl/*
// @require     http://www.babbage.com/library/Babbage_Javascript_Library.js
// @version     9-4-2016
// @grant   		addGlobalStyle
// @grant       SetRoleForID
// @grant       SetRoleForClassname
// @grant       SetAttributeForClassname
// @grant       SetRoleAndLabelForID
// @grant       SetLabelForIDForID
// ==/UserScript==
function SetRoleAndLabelForID(xxid,rolename,label)
{
  SetAttributeForID("aria-label",xxid,label);	
  SetRoleForID(xxid,rolename);
  // SetLabelForIDForID(xxid,label);  
}

// *********************** Startscherm ******************************************
SetRoleAndLabelForID("helpIcon","button","bekijk de verbeteringen");
SetRoleAndLabelForID("quicklaunch_fullscreen","button","Open dit scherm in een nieuw venster");
SetRoleAndLabelForID("quicklaunch_add","button","voeg nieuwe widget toe");
SetRoleAndLabelForID("helpMenu_container","button","Help onderwerpen");
SetRoleAndLabelForID("notificationIcon","button","Berichten");
SetRoleAndLabelForID("logo","button","Introductiepagina");

// *********************** Eigen Woningen ******************************************
SetAttributeForClassname("aria-label","fa fa-print printerIcon","Printen");
SetRoleAndLabelForID("searchbar_button","button","Berichten");
SetRoleAndLabelForID("buttonmenu_buttonmodify","button","Wijzigen");
SetRoleForClassname("fa fa-bars hoverIcon","button");

// De volgende knoppen worden niet gewijzigd, deze moeten OF onder een bookmarklet OF een knop
SetRoleForClassname("modify fa fa-pencil help tooltipstered gridMenuButton","button");
SetAttributeForClassname("aria-label","modify fa fa-pencil help tooltipstered gridMenuButton","Wijzigen");

// *********************** Oude comments ******************************************

// Eerste testje en dat werkte  SetRoleForClassname("headerlabel","button");
// SetRoleForClassname("component actionMenu gridMenuButton help fa fa-bars tooltipstered","button");
// SetRoleForClassname("searchbutton search expectedAction searchbutton fa fa-search gridMenuButton","button");
// SetRoleForClassname("fa fa-print","button");
// aanroep SetAttributeForClassname("role","checkbox_icon","checkbox");
// SetAttributeForClassname("aria-label","fa fa-inbox","Role_Name")
// SetRoleForID("generated2_46","button" )

// SetAttributeForClassname("aria-label","icon menuitem title base base-actionmenu tooltipstered","Hoofdmenu");
// SetLabelForIDForID(xxid,label("toplevelActionmenu","Toplevel Menu");
// SetRoleAndLabelForID("fa fa-question-circle","button","bekijk de verbeteringen" );

// SetRoleForID("helpIcon","button" );
// SetAttributeForID("aria-label","helpIcon","bekijk de verbeteringen" );
