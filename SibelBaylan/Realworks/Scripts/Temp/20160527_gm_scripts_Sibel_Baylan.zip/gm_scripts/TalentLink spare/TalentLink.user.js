// ==UserScript==
// @name Talentlink Script
// @namespace http://www.babbage.com/
// @description Change The Headers To Blue
// @include https://emea3.mrtedtalentlink.com/*
// @require http://www.babbage.com/library/Babbage_Javascript_Library.js
// @grant addGlobalStyle
// @grant SetRoleForID
// @grant SetRoleForClassname
// @grant SetAttributeForClassname
// ==/UserScript==


function addGlobalStyle(css) 
{
var head, style;
head = document.getElementsByTagName('head')[0];
if (!head) { return; }
style = document.createElement('style');
style.type = 'text/css';
style.innerHTML = css;
head.appendChild(style);
}



// ctrl+alt+j om java fouten te bekijken

// deze werken wél
 SetRoleForClassname("typeBtn","button");
 SetRoleForClassname("searchBtn","button");
 SetRoleForClassname("custom-item helpItem l0","button");
 SetRoleForClassname("preferencesItem l0","button");
// SetRoleForClassname("last custom-item logoutItem l0","button"); 
 SetAttributeForClassname("role","last custom-item logoutItem l0","button"); 


// deze werken niet => waarom???
 SetRoleForClassname("dialog_help","button");
 SetRoleForClassname("dialog_stickyNotes","button");
 SetRoleForClassname("dialog_config" ,"button");
 SetRoleForClassname("dialog_close" ,"button");
 SetRoleForClassname("dialog_minimize" ,"button");
 SetRoleForClassname("dialog_maximize" ,"button");


// SetRoleForID("mailchimpSF_main_css-css","banner");

 addGlobalStyle('#content h1 { color: #69DEFC !important; }');