// ==UserScript==
// @name        Realworks CRM - E-mail
// @namespace   http://www.babbage.com/
// @include     https://crm.realworks.nl/servlets/objects/email.email/new
// @require     http://www.babbage.com/library/Babbage_Javascript_Library.js
// @version     9-4-2016
// @grant   		addGlobalStyle
// @grant       SetRoleForID
// @grant       SetRoleForClassname
// @grant       SetAttributeForClassname
// @grant       SetRoleAndLabelForID
// @grant       SetLabelForIDForID
// ==/UserScript==

function SetRoleAndLabelForID(xxid,rolename,label)
{
  SetAttributeForID("aria-label",xxid,label);
  SetRoleForID(xxid,rolename);
  // SetLabelForIDForID(xxid,label);
}

/*
De volgende code staat ook in de online Babbage Library, maar voor test doeleinden ook lokaal geplaatst.
Dit om te testen of het verschil maakt met het plaatsen van labels en rollen op knoppen.
*/
function SetAttributeForClassname(Attribute,Class_Name,Role_Name)
{
  var x = document.getElementsByClassName(Class_Name);
  for (var i = 0; i < x.length; i++)
    {
      x[i].setAttribute(Attribute, Role_Name);
    }        
}

function SetRoleForClassname(Class_Name, Role_Name)
{
	SetAttributeForClassname("role",Class_Name,Role_Name)
}

// *********************** E-mail ***********************
SetRoleAndLabelForID("sendButton","button","Versturen");
SetRoleAndLabelForID("bijlagen_button","button","Bijlagen");
SetRoleAndLabelForID("cke_17","button","Plakken als platte tekst"); // Werkt ook niet?

SetRoleForClassname("labelsearch-icon fa fa-search gridMenuButton","button");
SetAttributeForClassname("aria-label","labelsearch-icon fa fa-search gridMenuButton","Relatie zoeken");
SetRoleForClassname("fa fa-plus gridMenuButton","button");
SetAttributeForClassname("aria-label","fa fa-plus gridMenuButton","Toevoegen...");
SetRoleForClassname("fa fa-times labelsearch gridMenuButton","button");
SetAttributeForClassname("aria-label","fa fa-times labelsearch gridMenuButton","Verwijderen");
SetRoleForClassname("labelsearch-icon fa fa-bars tooltipstered gridMenuButton","button");
SetAttributeForClassname("aria-label","labelsearch-icon fa fa-bars tooltipstered gridMenuButton","Opties menu");

/*
Exception: ReferenceError: SetAttributeForID is not defined
SetRoleAndLabelForID@Scratchpad/1:20:3
@Scratchpad/1:31:3
*/
