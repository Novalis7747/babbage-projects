// ==UserScript==
// @name        Realworks CRM - Eigen Woningen
// @namespace   http://www.babbage.com/
// @include     https://crm.realworks.nl/servlets/objects/broker.brokerobject/searchscreen
// @version     1
// @require     http://www.babbage.com/library/Babbage_Javascript_Library.js
// @grant   		addGlobalStyle
// @grant       SetRoleForID
// @grant       SetRoleForClassname
// @grant       SetAttributeForClassname
// @grant       SetRoleAndLabelForClassName
// @grant       SetRoleAndLabelForID
// @grant       SetLabelForIDForID
// ==/UserScript==


function MyFunction()
{
  
  // De volgende knoppen zijn ten tijden van het afronden van deze js nog niet op het formulier aanwezig 
  //  SetRoleForClassname("modify fa fa-pencil help tooltipstered gridMenuButton","button");
  // SetAttributeForClassname("aria-label","modify fa fa-pencil help tooltipstered gridMenuButton","Wijzigen");
  // is geworden: ... zijn overigens allemaal van sneltoets voorzien dus  eigenlijk niet echt nodig
  SetRoleAndLabelForClass("modify fa fa-pencil help tooltipstered gridMenuButton","button","Wijzigen");
  SetRoleAndLabelForClass("new fa fa-plus help tooltipstered gridMenuButton","button","Nieuw");
  SetRoleAndLabelForClass("markInactive fa fa-eye-slash help tooltipstered gridMenuButton","button","Op actief of inactief zetten");
  SetRoleAndLabelForClass("inactive_1 inactiveButton help fa fa-eye tooltipstered gridMenuButton","button","Alles,  actief of inactief");  
  SetRoleAndLabelForClass("component actionMenu gridMenuButton help fa fa-bars tooltipstered","button","diversen");

  // De iconen in de tabelcellen die pas 
  SetRoleAndLabelForClass("fa fa-print printerIcon","button","Printen");
  SetRoleAndLabelForClass("fa fa-bars hoverIcon","button","Acties");
  SetLabelForClassname("hitarea expandable-hitarea lastExpandable-hitarea","Uitklappen")
  
//  alert("Hello");
}


var btn = document.createElement("BUTTON");
    document.body.appendChild(btn);
    btn.innerHTML= "Babbage Toegang     :"+document.getElementsByTagName('iframe')[0].name;
    btn.id="A2345";
    document.getElementById("A2345").addEventListener("click", MyFunction);
    SetAttributeForID("accesskey","A2345","o");


// *********************** Eigen Woningen Zijn bij de start aanwezig  ******************************************
SetAttributeForClassname("aria-label","fa fa-print printerIcon","Printen");
SetRoleAndLabelForID("searchbar_button","button","Berichten");
SetRoleAndLabelForID("buttonmenu_buttonmodify","button","Wijzigen");
