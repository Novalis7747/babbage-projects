/*
  Er kan geen gebruik gemaakt worden van een externe library, zoals de "Babbage JavaScript Library".
  Dit omdat de browser, vanwege HTTPS, geen externe scripts toestaat.
  Gebruikgemaakt van: http://mrcoles.com/bookmarklet/
*/
function SetAttributeForClassname(Attribute, Class_Name, Role_Name) {
  var x = document.getElementsByClassName(Class_Name);
  for (var i = 0; i < x.length; i++) {
    x[i].setAttribute(Attribute, Role_Name);
  }
}
function SetRoleForClassname(Class_Name, Role_Name) {
  SetAttributeForClassname("role", Class_Name, Role_Name);
}
function SetLabelForClassname(Class_Name, label) {
  SetAttributeForClassname("aria-label", Class_Name, label);
}
function SetRoleAndLabelForClass(Class_Name, Role_Name, label) {
  console.log("function SetRoleAndLabelForClass" + Class_Name + " " + Role_Name + " " + label);
  SetRoleForClassname(Class_Name, Role_Name);
  SetLabelForClassname(Class_Name, label);
}
SetRoleAndLabelForClass('fa fa-backward', 'button', 'Een jaar terug navigeren');
SetRoleAndLabelForClass('fa fa-play fa-rotate-180', 'button', 'Een maand terug navigeren');
SetRoleAndLabelForClass('fa fa-play', 'button', 'Een maand vooruit navigeren');
SetRoleAndLabelForClass('fa fa-forward', 'button', 'Een jaar vooruit navigeren');
/*
  De volgende code werkt nog niet. Je kunt deze elementen wel vinden onder deze class name,
  maar een label er aanhangen geeft geen resultaat?
*/
SetLabelForClassname('fa fa-plus-circle', 'Nieuwe afspraak plannen');
