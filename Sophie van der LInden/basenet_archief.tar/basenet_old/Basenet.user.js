// ==UserScript==
// @name         Basenet (Old)
// @version      20200218-1200
// @author       LdR & PD, Babbage Automation, Roosendaal
// @namespace    https://www.babbage.com/
// @supportURL   https://www.babbage.com/contact/
// @description  Toegankelijkheid van de webapplicatie "Basenet" verbeteren
// @match        *://old.basenet.nl/*
// @grant        none
// ==/UserScript==

// --- [ USERSCRIPT NOTITIES ] ---
// ==Developer==
// @browser      Firefox ESR (Versie 72.0.2 (x64))
// @extension    TamperMonkey (Versie 4.10.6105)
// ==/Developer==

// ==Validator==
// @validator    JSLint (Edition 2020.01.17)
// @url          https://www.jslint.com/
// @help         https://www.jslint.com/help.html
// @settings     Assume: "a browser"
// @settings     Tolerate: "long lines"
// ==/Validator==

// --- [ VALIDATOR SETTINGS ] ---
// Automatisch instellen van bovenstaande @SETTINGS voor JSLINT:
/*jslint
    browser, long
*/

// --- [ GLOBALE VARIABELEN ] ---
var localDebug = false;
var scriptName = "Basenet";

// --- [ MUTATIE OBSERVER CONTAINER EN CONFIGURATIE ] ---
var container = document;
var config = {
    attributes: true,
    childList: true,
    subtree: true,
    attributeFilter: ["class"]
};

// --- [ DEBUG FUNCTIE ] ---
function debugConsoleMessage(level, message) {
    // Geeft een DEBUG MESSAGE al dan wel of niet weer.
    // Dit is afhankelijk van de VARIABELE localDebug:
    try {
        // Alleen een melding geven als LOCALDEBUG waar is:
        if (localDebug) {
            // LEVEL 1 geeft alleen de boodschap weer:
            if (level === 1) {
                window.console.log("       ", message);
            }
            // LEVEL 2 geeft de boodschap inclusief
            // het aantal milliseconden weer:
            if (level === 2) {
                var newDate = new Date();
                var sec = newDate.getSeconds();
                var ms = newDate.getMilliseconds();
                window.console.log(message, sec, ms, "ss:ms.");
            }
        }
    } catch (err) {
        window.console.log("Babbage debugConsoleMessage: " + err.message);
    }
}

// --- [ FUNCTIES ] ---
function setRoleLabelForClassName(className, role, label) {
    // Stel een ARIA-ROL en ARIA-LABEL in voor een specifiek ELEMENT:
    try {
        var element = document.getElementsByClassName(className);
        var elem = null;
        var i = 0;
        // Controleer of de VARIABELE een ELEMENT kent:
        if (element !== null) {
            while (element[i]) {
                // Controleer de lengte van ARGUMENT ROLE:
                if (role.length > 0) {
                    // Bestaat de ROLE al en is deze hetzelfde als
                    // wat je gaat toewijzen? Dan overslaan:
                    if (element[i].getAttribute("role") !== role) {
                        element[i].setAttribute("role", role);
                    }
                }
                // Controleer de lengte van ARGUMENT LABEL:
                if (label.length > 0) {
                    // Bestaat het LABEL al en is deze hetzelfde als
                    // wat je gaat toewijzen? Dan overslaan:
                    if (element[i].getAttribute("aria-label") !== label) {
                        element[i].setAttribute("aria-label", label);
                    }
                }
                // ACCESSKEY toevoegen specifiek voor de ZOEK knop:
                if (className === "searchbutton") {
                    // Bestaat de KLASSE al en is de waarde ervan hetzelfde
                    // als wat je gaat toewijzen? Dan overslaan:
                    if (element[i].getAttribute("accesskey") !== "z") {
                        element[i].setAttribute("accesskey", "z");
                    }
                }
                // ACCESSKEY toevoegen specifiek voor de knoppen om een BIJLAGE te downloaden:
                if (className === "gwt-HTML archiveButton gridMenuButton expectedAction") {
                    // Bestaat de KLASSE al en is de waarde ervan hetzelfde
                    // als wat je gaat toewijzen? Dan overslaan:
                    if (element[i].getAttribute("accesskey") !== "b") {
                        element[i].setAttribute("accesskey", "b");
                    }
                }
                if (className === "gwt-HTML downloadButton gridMenuButton expectedAction") {
                    // Bestaat de KLASSE al en is de waarde ervan hetzelfde
                    // als wat je gaat toewijzen? Dan overslaan:
                    if (element[i].getAttribute("accesskey") !== "d") {
                        element[i].setAttribute("accesskey", "d");
                    }
                }
                // ROL toevoegen specifiek voor een aantal knoppen:
                if (className === "gridMenuButton") {
                    // Achterhaal een ATTRIBUUT en als de waarde
                    // overeenkomt dan pas een ROL toekennen:
                    if (element[i].getAttribute("data-crm-event-tracking-id") === "Overzetten") {
                        element[i].setAttribute("role", "button");
                    }
                    if (element[i].getAttribute("data-crm-event-tracking-id") === "Download") {
                        element[i].setAttribute("role", "button");
                    }
                    if (element[i].getAttribute("data-crm-event-tracking-id") === "Upload") {
                        element[i].setAttribute("role", "button");
                    }
                }
                // Voorzie de rij van een ROLOMSCHRIJVING indien een e-mail ongelezen is:
                if (className === "emailinfo unread ") {
                    elem = element[i].parentNode.parentNode;
                    // Controleer of de VARIABELE niet leeg is en
                    // of je de TABLE ROW te pakken hebt:
                    if (elem !== null && elem.nodeName === "TR") {
                        elem.setAttribute("aria-roledescription", "ongelezen e-mail");
                    }
                }
                i += 1;
            }
        }
    } catch (err) {
        debugConsoleMessage(1, "setRoleLabelForClassName: " + err.message);
    }
}

function setRoleLabelForId(id, role, label) {
    // Stel een ARIA-ROL en ARIA-LABEL in voor een specifiek ELEMENT:
    try {
        var element = document.getElementById(id);
        var elementen;
        var i = 0;
        if (element !== null && element !== undefined) {
            // ---------------------------------
            // --- [ TOEGEVOEGD 2020-02-18 ] ---
            // ---------------------------------
            // Maak een uitzondering voor het SNELMENU:
            if (id === "quickMenu_container") {
                // Verkrijg alle KIND ELEMENTEN van het type ITALIC:
                elementen = element.getElementsByTagName("I");
                if (elementen !== null && elementen !== undefined) {
                    while (elementen[i]) {
                        // Bewerk alleen het juiste ELEMENT:
                        if (elementen[i].className === "fa fa-th-list") {
                            // Controleer de lengte van ARGUMENT ROLE:
                            if (role.length > 0) {
                                elementen[i].setAttribute("role", role);
                            }
                            // Controleer de lengte van ARGUMENT LABEL:
                            if (label.length > 0) {
                                elementen[i].setAttribute("aria-label", label);
                            }
                        }
                        i += 1;
                    }
                }
            } else {
                // Controleer de lengte van ARGUMENT ROLE:
                if (role.length > 0) {
                    element.setAttribute("role", role);
                }
                // Controleer de lengte van ARGUMENT LABEL:
                if (label.length > 0) {
                    element.setAttribute("aria-label", label);
                }
            }
        }
    } catch (err) {
        debugConsoleMessage(1, "setRoleLabelForId: " + err.message);
    }
}

function changeAttributeForId(id, attribute, value) {
    // Stel een ARIA-ROL en ARIA-LABEL in voor een specifiek ELEMENT:
    try {
        var element = document.getElementById(id);
        if (element !== null) {
            // Controleer de lengte van ATTRIBUTE en VALUE:
            if (attribute.length > 0 && value.length > 0) {
                element.setAttribute(attribute, value);
            }
        }
    } catch (err) {
        debugConsoleMessage(1, "changeAttributeForId: " + err.message);
    }
}

function setLabelOnEditField(className) {
    // Plaats een juiste LABEL op de INPUT ELEMENTEN:
    try {
        var debug = false;
        var element = document.getElementsByClassName(className);
        var i = 0;
        var label = null;
        // Controleer of de VARIABELE een ELEMENT kent:
        if (element !== null) {
            while (element[i]) {
                // Controleer of het ELEMENT dat je zoekt wel bestaat:
                if (element[i].parentNode.childNodes[1].childNodes[0] !== undefined) {
                    // Controleer of de PARENT, daarvan het KIND en daarvan
                    // ook het KIND van het type LABEL is, zo ja, doorgaan:
                    if (element[i].parentNode.childNodes[1].childNodes[0].nodeName === "LABEL") {
                        label = element[i].parentNode.childNodes[1].childNodes[0].innerHTML;
                        // Controleer de lengte van VARIABELE LABEL:
                        if (label.length > 0) {
                            // Betreft het geen DATUM INVOERVELD:
                            if (element[i].className !== "dateinput") {
                                // Bestaat het LABEL al en is deze hetzelfde als
                                // wat je gaat toewijzen? Dan overslaan:
                                if (element[i].getAttribute("aria-label") !== label) {
                                    element[i].setAttribute("aria-label", label);
                                    // Geef het LABEL in de CONSOLE weer ter verificatie:
                                    if (debug) {
                                        debugConsoleMessage(1, label);
                                    }
                                }
                            }
                            // Betreft het wel een DATUM INVOERVELD:
                            if (element[i].className === "dateinput") {
                                if (element[i].childNodes[1].nodeName === "INPUT") {
                                    // Bestaat het LABEL al en is deze hetzelfde als
                                    // wat je gaat toewijzen? Dan overslaan:
                                    if (element[i].childNodes[1].getAttribute("aria-label") !== label) {
                                        element[i].childNodes[1].setAttribute("aria-label", label);
                                        // Geef het LABEL in de CONSOLE weer ter verificatie:
                                        if (debug) {
                                            debugConsoleMessage(1, label);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                i += 1;
            }
        }
    } catch (err) {
        debugConsoleMessage(1, "setLabelOnEditField: " + err.message);
    }
}

function onClassMutation(mutation) {
    // MUTATIES gefilterd op ATTRIBUTE soort KLASSE:
    var classes = mutation.classList;
    if (!classes) {
        return;
    }
    // Wanneer een tabblad geselecteerd is:
    if (mutation.classList.contains("tabheaderitem_select")) {
        mutation.setAttribute("aria-selected", "true");
    // Wanneer een tabblad niet geselecteerd is:
    } else if (mutation.classList.contains("tabheaderitem_lo")) {
        mutation.setAttribute("aria-selected", "false");
    }
}

function onChildMutation(mutation) {
    // MUTATTIES gefilterd op de soort CHILDLIST:
    var i = 0;
    var mi = 0;
    // Verkrijg alle ELEMENTEN met het ATTRIBUUT TOOLTIP:
    var tooltips = document.querySelectorAll("[tooltip]");
    var tooltip = null;
    var mouseOver = "this.setAttribute('aria-describedby', 'tooltip');";
    var mouseOut = "this.removeAttribute('aria-describedby');";
    while (tooltips[i]) {
        tooltip = tooltips[i].getAttribute("tooltip");
        // Een groot aantal ELEMENTEN heeft wel een ATTRIBUUT TOOLTIP
        // maar deze is leeg. Behandel alleen ELEMENTEN waarvan de
        // ATTRIBUUT TOOLTIP ook werkelijk een tooltip bevat:
        if (tooltip.length > 0) {
            // Bestaat ONMOUSEOVER al en is deze hetzelfde als
            // wat je gaat toewijzen? Dan overslaan:
            if (tooltips[i].getAttribute("onmouseover") !== mouseOver) {
                tooltips[i].setAttribute("onmouseover", mouseOver);
            }
            // Bestaat ONMOUSEOUT al en is deze hetzelfde als
            // wat je gaat toewijzen? Dan overslaan:
            if (tooltips[i].getAttribute("onmouseout") !== mouseOut) {
                tooltips[i].setAttribute("onmouseout", mouseOut);
            }
            // Bestaat de ROLE al en is deze hetzelfde als
            // wat je gaat toewijzen? Dan overslaan:
            if (tooltips[i].getAttribute("role") !== "link") {
                tooltips[i].setAttribute("role", "link");
            }
        }
        i += 1;
    }
    // DEBUG loop om de toegevoegde NODES te inspecteren:
    while (mutation.addedNodes[mi]) {
        // window.console.log(mutation.addedNodes[mi]);
        mi += 1;
    }
    // Stel alle rollen en labels in voor ElEMENTEN met een specifieke KLASSE naam:
    // Hoofdpagina:
    setRoleLabelForClassName("dragbox-head-title", "heading", "");
    setRoleLabelForClassName("header", "heading", "");
    setRoleLabelForClassName("fa-print", "button", "printen");
    setRoleLabelForClassName("tooltipster-content", "navigation", "menu geopend");
    setRoleLabelForClassName("lettersetting isIcon tooltipster fa fa-cogs tooltipstered", "button", "instellingen");
    setRoleLabelForClassName("isIcon fa fa-plus-circle hideTooltipsterOnTouch tooltipstered", "button", "toevoegen");
    setRoleLabelForClassName("column ui-draggable ui-sortable", "navigation", "menu geopend");
    setRoleLabelForClassName("close fa fa-times-circle", "button", "sluiten");
    setRoleLabelForClassName("gridMenuButton expectedAction", "button", "");
    setRoleLabelForClassName("expectedAction gridMenuButton", "button", "");
    // Correspondentie / Documenten en E-mails:
    setRoleLabelForClassName("gridMenuButton fa fa-edit help tooltipstered", "button", "wijzigen");
    setRoleLabelForClassName("component actionMenu gridMenuButton help fa fa-plus tooltipstered", "button", "nieuw...");
    setRoleLabelForClassName("fa fa-trash-o help tooltipstered gridMenuButton", "button", "verwijderen");
    setRoleLabelForClassName("component actionMenu gridMenuButton help fa fa-bars tooltipstered", "button", "acties...");
    setRoleLabelForClassName("noResultsFound", "alert", "");
    setRoleLabelForClassName("labelSearchPopUpText", "link", "");
    // Correspondentie / E-mail boxes:
    setRoleLabelForClassName("gwt-PushButton needsclick gridMenuButton icon fa fa-plus tooltipster help image_with_button expectedAction tooltipstered gwt-PushButton-up", "button", "nieuw");
    setRoleLabelForClassName("gwt-PushButton needsclick gridMenuButton icon fa fa-floppy-o tooltipster help image_with_button tooltipstered gwt-PushButton-up", "button", "bewaren");
    setRoleLabelForClassName("gwt-PushButton needsclick gridMenuButton icon fa fa-reply tooltipster help image_with_button tooltipstered gwt-PushButton-up", "button", "antwoorden");
    setRoleLabelForClassName("gwt-PushButton needsclick gridMenuButton icon fa fa-reply-all tooltipster help image_with_button tooltipstered gwt-PushButton-up", "button", "allen antwoorden");
    setRoleLabelForClassName("gwt-PushButton needsclick gridMenuButton icon fa fa-arrow-right tooltipster help image_with_button tooltipstered gwt-PushButton-up", "button", "doorsturen");
    setRoleLabelForClassName("gwt-PushButton needsclick gridMenuButton icon fa fa-share-square-o tooltipster help image_with_button gwt-PushButton-up", "button", "verplaatsen");
    setRoleLabelForClassName("gwt-PushButton needsclick gridMenuButton isIcon fa fa-print tooltipster help image_with_button tooltipstered gwt-PushButton-up", "button", "afdrukken");
    setRoleLabelForClassName("gwt-PushButton gridMenuButton icon fa fa-floppy-o tooltipster help image_with_button corres_button_save_one expectedAction tooltipstered gwt-PushButton-up", "button", "opslaan");
    setRoleLabelForClassName("gwt-PushButton gridMenuButton icon fa tooltipster help image_with_button tooltipstered icon fa fa-link gwt-PushButton-up", "button", "gerelateerd");
    setRoleLabelForClassName("gwt-HTML baseEmailLabel", "link", "");
    setRoleLabelForClassName("labelsearch-icon fa fa-search gridMenuButton", "button", "zoeken");
    setRoleLabelForClassName("fa fa-times-circle closeIcon", "button", "sluiten");
    setRoleLabelForClassName("emailinfo unread ", "", "");
    // Correspondentie / E-mail boxes / Nieuwe e-mail (nieuw venster):
    setRoleLabelForClassName("expectedAction fa fa-send tooltipstered gridMenuButton", "button", "versturen");
    setRoleLabelForClassName("fa fa-paperclip tooltipstered gridMenuButton", "button", "bijlagen");
    setRoleLabelForClassName("emailtemplatebutton fa fa-file-text tooltipstered gridMenuButton", "button", "gebruik standaard template");
    setRoleLabelForClassName("cke_editable cke_editable_themed cke_contents_ltr cke_show_borders", "navigation", "");
    // Correspondentie / E-mail boxes / E-mail (nieuw venster):
    setRoleLabelForClassName("gwt-HTML archiveButton gridMenuButton expectedAction", "button", "bewaar alles");
    setRoleLabelForClassName("gwt-HTML downloadButton gridMenuButton expectedAction", "button", "download alles");
    setRoleLabelForClassName("gwt-HTML previewImage base-document-preview tooltipstered", "button", "preview");
    setRoleLabelForClassName("gwt-HTML archiveImage fa fa-save tooltipstered", "button", "bijlage archiveren");
    setRoleLabelForClassName("gwt-HTML revisionImage fa fa-files-o tooltipstered", "button", "opslaan met revisie");
    setRoleLabelForClassName("gwt-HTML downloadImage fa fa-file-pdf-o", "button", "pdf");
    // Correspondentie / E-mail boxes / E-mail / Bijlagen bewaren (nieuw venster):
    setRoleLabelForClassName("fa fa-upload help tooltipstered gridMenuButton", "button", "upload");
    // Advocatuur / Dossiers:
    setRoleLabelForClassName("new fa fa-plus help tooltipstered gridMenuButtonOver", "button", "nieuw");
    setRoleLabelForClassName("modify fa fa-pencil help tooltipstered gridMenuButton", "button", "wijzigen");
    setRoleLabelForClassName("component actionMenu gridMenuButton help fa fa-bars tooltipstered", "button", "acties...");
    setRoleLabelForClassName("searchbutton", "button", "zoeken");
    setRoleLabelForClassName("component multiselectbox-GWT", "navigation", "menu geopend");
    setRoleLabelForClassName("gwt-PopupPanel", "navigation", "menu geopend");
    setLabelOnEditField("formelement");
    setLabelOnEditField("dateinput");
    // Advocatuur / Dossiers / Dossier (nieuw venster):
    setRoleLabelForClassName("save fa fa-floppy-o help tooltipstered gridMenuButton", "button", "bewaar");
    setRoleLabelForClassName("save close base base-bewaar-sluit help tooltipstered gridMenuButton", "button", "bewaar en sluit");
    setRoleLabelForClassName("close fa fa-times help tooltipstered gridMenuButton", "button", "sluiten");
    setRoleLabelForClassName("tabheaderitem_select", "link", "");
    setRoleLabelForClassName("tabheaderitem_lo", "link", "");
    setRoleLabelForClassName("reportMenu_container", "button", "documenten menu...");
    setRoleLabelForClassName("quickMenu_container", "button", "snelmenu...");
    setRoleLabelForClassName("fa fa-eye-slash help tooltipstered gridMenuButton", "button", "zet op (in)actief");
    setRoleLabelForClassName("inactive_1 inactiveButton help fa fa-eye tooltipstered gridMenuButton", "button", "overzicht aanpassen...");
    setRoleLabelForClassName("fa fa-pencil help tooltipstered gridMenuButton", "button", "wijzigen");
    setRoleLabelForClassName("fa fa-plus help tooltipstered gridMenuButton", "button", "nieuw");
    setRoleLabelForClassName("fa fa-envelope help tooltipstered gridMenuButton", "button", "nieuwe mailing");
    setRoleLabelForClassName("fa fa-refresh help tooltipstered gridMenuButton", "button", "vernieuwen");
    setRoleLabelForClassName("base base-documents_email help tooltipstered gridMenuButton", "button", "correspondentie");
    setRoleLabelForClassName("fa fa-history help tooltipstered gridMenuButton", "button", "relatiehistorie");
    // Sales / Suspects:
    setRoleLabelForClassName("markInactive fa fa-eye-slash help tooltipstered gridMenuButton", "button", "zet op (in)actief");
    setRoleLabelForClassName("gridMenuButton", "", "");
    // Sales / Prospects / Prospectproject:
    setRoleLabelForClassName("cke_wysiwyg_frame cke_reset", "navigation", "");
    setRoleLabelForClassName("nextitem fa fa-chevron-right help tooltipstered gridMenuButton", "button", "volgende prospect");
    setRoleLabelForClassName("previousitem fa fa-chevron-left help tooltipstered gridMenuButton", "button", "vorige prospect");
    setRoleLabelForClassName("labelsearch_result nonedit", "link", "");
    setRoleLabelForClassName("fa fa-plus gridMenuButton", "button", "plusteken");
    // Agenda / Taken / Agenda:
    setRoleLabelForClassName("fa fa-search help tooltipstered gridMenuButton", "button", "doorzoek agenda");
    setRoleLabelForClassName("fa fa-calendar help tooltipstered gridMenuButton", "button", "weergave aanpassen");
    setRoleLabelForClassName("fa fa-backward", "button", "jaar terug");
    setRoleLabelForClassName("fa fa-play fa-rotate-180", "button", "maand terug");
    setRoleLabelForClassName("fa fa-play", "button", "maand vooruit");
    setRoleLabelForClassName("fa fa-forward", "button", "jaar vooruit");
    // Telefonie / Call Registratie:
    setRoleLabelForClassName("plaintextarea textarea", "navigation", "");
    setRoleLabelForClassName("fa fa-stack-2x fa fa-money", "navigation", "icoon sales en factuur");
    // Stel alle rollen en labels in voor ElEMENTEN met een specifiek ID:
    // Hoofdpagina:
    setRoleLabelForId("noflashheader", "navigation", "");
    setRoleLabelForId("userMenuImage", "button", "");
    setRoleLabelForId("notificationIcon", "button", "notificaties");
    setRoleLabelForId("notifications", "navigation", "notificaties");
    setRoleLabelForId("quicklaunch_fullscreen", "button", "maximaliseren");
    setRoleLabelForId("helpMenu_container", "button", "help menu...");
    setRoleLabelForId("menuCreateNew", "button", "nieuw...");
    setRoleLabelForId("quickMenu_container", "button", "snelmenu...");
    // Correspondentie / Documenten en E-mails:
    setRoleLabelForId("savedQueryMenuTitle", "button", "opgeslagen zoekopdrachten");
    setRoleLabelForId("lepcode_include_subprojects", "", "inclusief subprojecten");
    setRoleLabelForId("lercode_popup", "navigation", "menu geopend");
    setRoleLabelForId("lepcode_popup", "navigation", "menu geopend");
    setRoleLabelForId("lercode_image_delete", "button", "relatie verwijderen");
    setRoleLabelForId("lepcode_image_delete", "button", "project verwijderen");
    // Correspondentie / E-mail boxes:
    setRoleLabelForId("emailbodyiframe", "navigation", "e-mail");
    setRoleLabelForId("div_emailquicklaunch", "button", "acties...");
    setRoleLabelForId("lercode_input", "", "relatie");
    setRoleLabelForId("multiSaveButton", "button", "bewaren");
    // Correspondentie / E-mail boxes / E-mail (nieuw venster):
    setRoleLabelForId("corres_button", "button", "bewaar");
    setRoleLabelForId("reply_button", "button", "antwoorden");
    setRoleLabelForId("replytoall_button", "button", "allen antwoorden");
    setRoleLabelForId("forward_button", "button", "doorsturen");
    setRoleLabelForId("source_button", "button", "download");
    changeAttributeForId("downloadList", "aria-hidden", "false");
    // Sales / Prospects:
    setRoleLabelForId("tooltip", "navigation", "");
    // Sales / Prospects / Prospectproject / Relatiekaart:
    setRoleLabelForId("haddresstab", "navigation", "adresgegevens");
    // Sales / Prospects / Prospectproject / Historie / E-mail:
    setRoleLabelForId("reply_to_mail_button", "button", "antwoorden");
    setRoleLabelForId("replytoall_mail_button", "button", "allen antwoorden");
    setRoleLabelForId("forward_mail_button", "button", "doorsturen");
    setRoleLabelForId("source_mail_button", "button", "downloaden");
}

// --- [ MUTATIE OBSERVER TOEVOEGEN ] ---
var domObserver = new MutationObserver(function (mutations) {
    // FUNCTIES die aangeroepen moeten worden nadat er een
    // mutatie binnen de CONTAINER heeft plaatsgevonden:
    try {
        var i = 0;
        while (mutations[i]) {
            // Er vinden twee soorten mutaties plaats, een
            // als CHILDLIST en de anders als ATTRIBUTE,
            // stuur beiden naar aparte functies:
            if (mutations[i].type === "childList") {
                onChildMutation(mutations[i]);
            }
            if (mutations[i].type === "attributes") {
                if (mutations[i].attributeName === "class") {
                    onClassMutation(mutations[i].target);
                }
            }
            i += 1;
        }
    } catch (err) {
        debugConsoleMessage(1, "domObserver: " + err.message);
    }
});

// --- [ MUTATIE OBSERVER STARTEN ] ---
// Daadwerkelijke start van de MUTATIE OBSERVER.
// CONTAINER en CONFIG worden aan het begin van
// dit script gedefinieerd:
domObserver.observe(container, config);

// --- [ EINDE SCRIPT ] ---
// Als de volgende melding in de CONSOLE wordt
// getoond, dan kan het script in ieder geval
// tot het eind foutloos uitgevoerd worden:
if (localDebug) {
    debugConsoleMessage(2, "Einde script voor " + scriptName + ":");
}
